package com.gocarshare.userservice.userservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GoCarShareUserServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(GoCarShareUserServiceApplication.class, args);
	}

}
