package com.gocarshare.userservice.userservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GoCarShareUserServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
